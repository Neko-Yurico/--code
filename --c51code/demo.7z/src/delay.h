#ifndef __DELAY_H_
#define __DELAY_H_

void Delay2US(int t);
void DelayMS(int t);

#endif